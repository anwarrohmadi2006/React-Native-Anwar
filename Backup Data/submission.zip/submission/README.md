# Proyek Analisis Data: Bike Sharing Dataset

- **Nama:** Anwar Rohmadi
- **ID Dicoding:** anwarrohmadi111

---

## 📂 Struktur Direktori

```
submission/
├── dashboard/
│   ├── main_data.csv      # Data harian (sudah dibersihkan)
│   ├── hour_data.csv      # Data per jam (sudah dibersihkan)
│   └── dashboard.py       # Streamlit dashboard
├── data/
│   ├── day.csv            # Dataset asli harian
│   └── hour.csv           # Dataset asli per jam
├── notebook.ipynb         # Notebook analisis lengkap
├── README.md
├── requirements.txt
└── url.txt
```

---

## ❓ Pertanyaan Bisnis

1. Bagaimana pengaruh musim (*season*) terhadap total dan rata-rata jumlah peminjaman sepeda harian sepanjang 2011–2012?
2. Pada jam berapa rata-rata peminjaman sepeda mencapai puncaknya di hari kerja dibandingkan hari libur/weekend sepanjang 2011–2012?

---

## ⚙️ Setup Environment

### Menggunakan pip

```bash
pip install -r requirements.txt
```

### Menggunakan conda (opsional)

```bash
conda create --name bike-sharing python=3.9
conda activate bike-sharing
pip install -r requirements.txt
```

---

## 🚀 Menjalankan Dashboard

```bash
cd dashboard
streamlit run dashboard.py
```

Dashboard akan terbuka otomatis di browser pada `http://localhost:8501`.

---

## 📊 Kesimpulan Analisis

- **Musim Fall (Gugur)** memiliki rata-rata peminjaman harian tertinggi (~5.644/hari); **Spring** terendah (~2.604/hari).
- **Hari kerja:** pola "M" dengan puncak jam **08:00** (berangkat) dan jam **17:00** (pulang).
- **Hari libur/weekend:** pola "bell curve" dengan puncak jam **12:00–13:00**.
- Analisis clustering menunjukkan demand tinggi berkorelasi kuat dengan suhu >20°C.
