# Proyek Analisis Data: Bike Sharing Dataset

## Setup Environment
```
pip install -r requirements.txt
```

## Run Dashboard
```
cd dashboard
streamlit run dashboard.py
```

## Dataset
Bike Sharing Dataset dari Capital Bikeshare system Washington D.C., mencakup tahun 2011-2012.

## Pertanyaan Analisis
1. Bagaimana pengaruh musim (season) terhadap jumlah peminjaman sepeda?
2. Pada jam berapa peminjaman sepeda paling tinggi di hari kerja vs hari libur?

## Kesimpulan
- Musim Fall memiliki peminjaman tertinggi, Spring terendah
- Hari kerja: puncak jam 8 (berangkat) dan jam 17 (pulang)
- Hari libur: puncak jam 12-13 (siang hari)
