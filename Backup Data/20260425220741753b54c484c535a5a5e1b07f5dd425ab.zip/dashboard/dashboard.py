import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Konfigurasi halaman
st.set_page_config(
    page_title='Bike Sharing Dashboard',
    page_icon='🚲',
    layout='wide'
)

# Load data
@st.cache_data
def load_data():
    day_df = pd.read_csv('main_data.csv')
    hour_df = pd.read_csv('hour_data.csv')
    day_df['dteday'] = pd.to_datetime(day_df['dteday'])
    hour_df['dteday'] = pd.to_datetime(hour_df['dteday'])
    return day_df, hour_df

day_df, hour_df = load_data()

# Sidebar filter
st.sidebar.title('🚲 Filter Data')
st.sidebar.markdown('---')

# Filter musim
all_seasons = day_df['season_label'].unique().tolist()
selected_seasons = st.sidebar.multiselect(
    'Pilih Musim:', options=all_seasons, default=all_seasons
)

# Filter tahun
all_years = sorted(day_df['yr'].unique().tolist())
year_labels = {0: '2011', 1: '2012'}
selected_year = st.sidebar.selectbox(
    'Pilih Tahun:', options=all_years, format_func=lambda x: year_labels[x]
)

# Filter data
filtered_day = day_df[
    (day_df['season_label'].isin(selected_seasons)) &
    (day_df['yr'] == selected_year)
]
filtered_hour = hour_df[hour_df['yr'] == selected_year]

# Header
st.title('🚲 Dashboard Analisis Bike Sharing')
st.markdown('**Dataset:** Capital Bikeshare System (2011-2012)')
st.markdown('---')

# Metrik utama
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric('Total Peminjaman', f"{filtered_day['cnt'].sum():,}")
with col2:
    st.metric('Rata-Rata Harian', f"{filtered_day['cnt'].mean():.0f}")
with col3:
    st.metric('Peminjaman Tertinggi', f"{filtered_day['cnt'].max():,}")
with col4:
    st.metric('Peminjaman Terendah', f"{filtered_day['cnt'].min():,}")

st.markdown('---')

# Tab visualisasi
tab1, tab2, tab3 = st.tabs(['📊 Peminjaman per Musim', '⏰ Pola per Jam', '🗓️ Heatmap Mingguan'])

with tab1:
    st.subheader('Pertanyaan 1: Bagaimana pengaruh musim terhadap peminjaman sepeda?')
    
    season_order = ['Spring', 'Summer', 'Fall', 'Winter']
    season_avg = filtered_day.groupby('season_label')['cnt'].mean().reindex(
        [s for s in season_order if s in filtered_day['season_label'].unique()]
    )
    
    col1, col2 = st.columns(2)
    with col1:
        fig, ax = plt.subplots(figsize=(8, 5))
        colors = ['#4CAF50', '#FF9800', '#F44336', '#2196F3']
        bars = ax.bar(season_avg.index, season_avg.values,
                      color=colors[:len(season_avg)], edgecolor='white')
        for bar, val in zip(bars, season_avg.values):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 30,
                    f'{val:.0f}', ha='center', fontweight='bold', fontsize=10)
        ax.set_title('Rata-Rata Peminjaman per Musim', fontweight='bold')
        ax.set_xlabel('Musim')
        ax.set_ylabel('Rata-Rata Peminjaman')
        ax.grid(axis='y', alpha=0.3)
        st.pyplot(fig)
        plt.close()
    
    with col2:
        weather_avg = filtered_day.groupby('weather_label')['cnt'].mean().sort_values(ascending=False)
        fig, ax = plt.subplots(figsize=(8, 5))
        sns.barplot(x=weather_avg.values, y=weather_avg.index, ax=ax, palette='viridis')
        ax.set_title('Rata-Rata Peminjaman per Cuaca', fontweight='bold')
        ax.set_xlabel('Rata-Rata Peminjaman')
        ax.set_ylabel('Kondisi Cuaca')
        st.pyplot(fig)
        plt.close()
    
    st.info('**Insight:** Musim Fall (Gugur) memiliki peminjaman tertinggi. Cuaca cerah mendorong lebih banyak peminjaman.')

with tab2:
    st.subheader('Pertanyaan 2: Pola jam peminjaman di hari kerja vs hari libur?')
    
    hour_work = filtered_hour[filtered_hour['workingday']==1].groupby('hr')['cnt'].mean()
    hour_holiday = filtered_hour[filtered_hour['workingday']==0].groupby('hr')['cnt'].mean()
    
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(hour_work.index, hour_work.values, marker='o', linewidth=2.5,
            color='#2196F3', label='Hari Kerja', markersize=4)
    ax.plot(hour_holiday.index, hour_holiday.values, marker='s', linewidth=2.5,
            color='#FF9800', label='Hari Libur/Weekend', markersize=4, linestyle='--')
    ax.set_title('Pola Peminjaman Sepeda per Jam: Hari Kerja vs Hari Libur', fontweight='bold')
    ax.set_xlabel('Jam (0-23)')
    ax.set_ylabel('Rata-Rata Peminjaman')
    ax.set_xticks(range(24))
    ax.legend()
    ax.grid(alpha=0.3)
    st.pyplot(fig)
    plt.close()
    
    col1, col2 = st.columns(2)
    with col1:
        if not hour_work.empty:
            peak_work = hour_work.idxmax()
            st.metric('Jam Puncak Hari Kerja', f'Jam {peak_work}:00',
                      delta=f'{hour_work[peak_work]:.0f} peminjaman rata-rata')
    with col2:
        if not hour_holiday.empty:
            peak_hol = hour_holiday.idxmax()
            st.metric('Jam Puncak Hari Libur', f'Jam {peak_hol}:00',
                      delta=f'{hour_holiday[peak_hol]:.0f} peminjaman rata-rata')
    
    st.info('**Insight:** Hari kerja pola "M" (jam 8 & 17), hari libur pola "bell curve" (jam 12-13).')

with tab3:
    st.subheader('Heatmap: Intensitas Peminjaman per Jam dan Hari')
    
    hour_weekday_pivot = filtered_hour.pivot_table(
        values='cnt', index='hr', columns='weekday_label', aggfunc='mean'
    )
    day_order = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    available_days = [d for d in day_order if d in hour_weekday_pivot.columns]
    hour_weekday_pivot = hour_weekday_pivot[available_days]
    
    fig, ax = plt.subplots(figsize=(12, 7))
    sns.heatmap(hour_weekday_pivot, cmap='YlOrRd', ax=ax, linewidths=0.5,
                cbar_kws={'label': 'Rata-Rata Peminjaman'})
    ax.set_title('Heatmap Peminjaman: Jam vs Hari dalam Seminggu', fontweight='bold')
    ax.set_xlabel('Hari dalam Seminggu')
    ax.set_ylabel('Jam (0-23)')
    ax.invert_yaxis()
    st.pyplot(fig)
    plt.close()

# Footer
st.markdown('---')
st.caption('Dashboard dibuat untuk Proyek Analisis Data | Belajar Fundamental Analisis Data | Dicoding')
