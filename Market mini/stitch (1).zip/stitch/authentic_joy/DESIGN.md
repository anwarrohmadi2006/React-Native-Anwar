```markdown
# Design System Strategy: The Joyful Curator

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Joyful Curator."** While many e-commerce platforms settle for a "warehouse" aesthetic—cluttered, loud, and utilitarian—this system treats retail as a high-end editorial experience. We combine the "Joyful" energy of a vibrant red palette with the "Authentic" trust of premium typography and "Fast" performance through minimalist, lightweight layouts.

To move beyond the "template" look, we embrace **Intentional Asymmetry**. Hero banners should utilize off-center focal points, and product grids should feel less like a rigid cage and more like a fluid gallery. We break the monotony of standard e-commerce through overlapping elements (e.g., product images breaking the container bounds) and high-contrast typography that guides the eye with editorial precision.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
Our color strategy is built on a "Vibrant Sophistication" model. We use `primary` (#b70032) as a precision tool—a surgical strike of energy—rather than a blunt instrument.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or containment. Boundaries must be defined through background color shifts. Use `surface-container-low` (#f3f3f4) sections sitting on a `surface` (#f9f9fa) background. This creates a modern, "seamless" look that feels faster and less restrictive.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine paper.
- **Base Layer:** `surface` (#f9f9fa)
- **Content Blocks:** `surface-container-low` (#f3f3f4)
- **Interactive Cards:** `surface-container-lowest` (#ffffff)
- **Pop-overs/Modals:** `surface-bright` (#f9f9fa)

### The "Glass & Gradient" Rule
To elevate the "Joyful" vibe, utilize a **Signature Texture**: A subtle linear gradient for high-impact CTAs moving from `primary` (#b70032) to `primary_container` (#e31143). For floating navigation or promotional overlays, use **Glassmorphism**: Apply a semi-transparent `surface` color with a 20px backdrop-blur to allow the vibrant product photography to bleed through the UI.

---

## 3. Typography: Editorial Authority
We use a dual-font pairing to balance personality with readability.

*   **Display & Headlines:** **Plus Jakarta Sans.** This typeface brings a modern, geometric "Joy" to the system. The high x-height and open apertures convey "Fast" and "Clean." Use `display-lg` for major promotional moments to create an "Editorial Magazine" feel.
*   **Body & Labels:** **Inter.** Chosen for its "Authentic" and "Trustworthy" qualities. Inter provides maximum legibility at small sizes for product specs and technical data.

**Hierarchy Strategy:** 
- Use `headline-lg` (2rem) in `on_surface` (#1a1c1d) for category headers.
- Use `label-md` (0.75rem) in `primary` (#b70032) for "Authenticity Badges" or "JD Central" markers to ensure they pop without cluttering the layout.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are banned in favor of **Ambient Light**.

*   **The Layering Principle:** Instead of a shadow, place a `surface-container-lowest` (#ffffff) card on a `surface-container-low` (#f3f3f4) background. The contrast in hex value provides a "soft lift" that feels architectural.
*   **Ambient Shadows:** If a floating effect is required (e.g., a "Quick Buy" button), use a shadow with a 32px blur, 4% opacity, and a color tint of `primary` (#b70032). This mimics a red-tinted light bounce, making the UI feel "Joyful" and integrated.
*   **The Ghost Border:** If a container needs separation on a white background, use `outline_variant` (#e4bdc2) at **15% opacity**. It should be felt, not seen.

---

## 5. Components: Precision & Speed

### Product Cards
*   **Rule:** Forbid divider lines. Use 24px of vertical white space (Spacing XL) to separate price from description.
*   **Authenticity Badges:** Use a `tertiary_container` (#008543) background with `on_tertiary_container` (#eeffed) text for "Authentic" tags. This deep green provides a "Trust" counterpoint to the energetic red.
*   **Image Handling:** Product photos should have no background (PNG) and slightly overlap the card top-edge to create a 3D effect.

### Promotional Banners
*   **Style:** Use the `primary_container` (#e31143) as a base.
*   **Composition:** 60% negative space, 40% high-fidelity imagery. Text should use `display-sm` (2.25rem) to demand attention.

### Buttons
*   **Primary:** High-pill shape (`rounded-full`). Gradient from `primary` to `primary_container`. No border.
*   **Secondary:** `surface-container-highest` background with `on_surface` text.
*   **Interactive State:** On hover, a 2px inner glow (using `primary_fixed`) should appear to simulate a "lit from within" effect.

### Navigation System
*   **The "Floating Dock":** For mobile, use a glassmorphic bottom bar. For desktop, a "Search-First" top bar using `surface-container-lowest` with a subtle `outline_variant` (10% opacity) ghost border.

---

## 6. Do's and Don'ts

### Do
*   **DO** use whitespace as a structural element. If an interface feels "slow," add more padding.
*   **DO** use "Joyful" micro-interactions: A slight 2-degree rotation on a category icon when hovered.
*   **DO** ensure "JD Central" badges are always accompanied by the `tertiary` (green) checkmark to reinforce authenticity.

### Don't
*   **DON'T** use 100% black (#000000). Use `on_surface` (#1a1c1d) for all text to maintain a premium, "soft" contrast.
*   **DON'T** use sharp corners. Everything must adhere to the `DEFAULT` (0.5rem) or `lg` (1rem) roundedness to feel approachable.
*   **DON'T** use "Standard" red. Only use the defined `primary` tokens to avoid the interface looking like a generic discount store. High-end retail is defined by its specific, intentional palette.